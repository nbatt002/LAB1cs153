#include "types.h"
#include "user.h"
//#include <stdio.h>
int main()
{
   // printf() displays the string inside quotation
   printf(1, "\n Hello, World! \n");
	exit(0);
        return 0;
}
